# Oracle of Ammon
