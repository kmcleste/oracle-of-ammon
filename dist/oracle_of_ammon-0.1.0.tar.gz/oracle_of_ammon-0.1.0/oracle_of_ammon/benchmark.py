from locust import HttpUser, between, task

class WebsiteUser(HttpUser):
    wait_time = between(0.2, 1)

    @task
    def attempt(self):
        self.client.post(url="/search", json={"query": "body armor", "params": {"Retriever": {"top_k": 10}}})
        #  self.client.get(url="/health")
        # self.client.get(url="/")
